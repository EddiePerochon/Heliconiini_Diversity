#' Plot specimens in tangent space
#'
#' This function is now defunct
#' 
#' 
plotTangentSpace<-function (){
  .Defunct("gm.prcomp", package = "geomorph", 
              msg = "plotTangentSpace has been removed from geomorph.
              A combination of gm.prcomp, summary.prcomp, and plot.gm.prcomp has much greater flexibility.
              One can also use picknplot.shape to generate warpgrids, anywhere in a plot.")
}
