#' Deprecated and defunct functions in geomorph
#'
#' The following function is now defunct
#'
#' 
#' @export
plotTangentSpace <- function(){
  .Defunct("gm.prcomp")
}

#' Deprecated and defunct functions in geomorph
#'
#' The following function is now defunct
#'
#' 
#' @export
plotGMPhyloMorphoSpace <- function(){
  .Defunct("gm.prcomp")
}
