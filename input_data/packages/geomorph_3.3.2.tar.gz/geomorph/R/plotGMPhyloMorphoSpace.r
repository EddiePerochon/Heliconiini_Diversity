#' Plot phylogenetic tree and specimens in tangent space
#'
#' This function is now defunct
#'   

plotGMPhyloMorphoSpace <- function(){
  .Defunct("gm.prcomp", package = "geomorph", 
              msg = "plotGMPhyloMorphospace has been removed from geomorph.
              A combination of gm.prcomp, summary.prcomp, and plot.gm.prcomp has much greater flexibility.
              One can also use picknplot.shape to generate warpgrids, anywhere in a plot.")
}
