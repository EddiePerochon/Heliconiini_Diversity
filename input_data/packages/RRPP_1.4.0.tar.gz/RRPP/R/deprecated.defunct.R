
#' Deprecated functions in RRPP
#'
#' The following function has been deprecated in RRPP
#'
#' This function has been deprecated. Use \code{\link{prep.lda}} instead.
#' 
#' @export
classify <- function(){
  .Deprecated("classify")
}



