library(testthat)
library(RRPP)

test_check("RRPP")
